/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
import DeckOfCards.CartaInglesa;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import java.util.*;
import solitaire.FoundationDeck;
import solitaire.SolitaireGame;
import solitaire.TableauDeck;

public class ControladorJuego {
    private final StackPane vistaMazo;
    private final Pane descarte;
    private final List<Pane> fundacion;
    private final List<Pane> columna;
    private final Runnable onVictoria;
    private final Map<StackPane, Carta> cartaPorNodo = new HashMap<>();
    private final double pasoSolape = 32;
    private final double margenSuperior = 12;
    private boolean victoriaMostrada = false;
    private SolitaireGame juego;
    private final AnimacionArrastre arrastre;
    private final Pane capaArrastre;


    public ControladorJuego(StackPane vistaMazo, Pane descarte, List<Pane> fundacion, List<Pane> columna, Runnable onVictoria,Pane capaArrastre) {
        this.vistaMazo = vistaMazo;
        this.descarte = descarte;
        this.fundacion = fundacion;
        this.columna = columna;
        this.onVictoria = onVictoria;
        this.arrastre = new AnimacionArrastre(fundacion, columna, descarte, cartaPorNodo, this::manejarValido, this::manejarInvalido, this::intentarConMotor,capaArrastre);
        this.capaArrastre= capaArrastre;
    }

    public void prepararNuevaPartida() {
        victoriaMostrada = false;
        juego = new SolitaireGame();
        limpiar();
        pintarDesdeMotor();
    }

    public void ejecutarAccionMazo() {
        if (juego.getDrawPile().hayCartas()) {
            juego.drawCards();
        } else {
            juego.reloadDrawPile();
        }
        refrescarWaste();
    }

    private void limpiar() {
        for (Pane b : fundacion) {
            b.getChildren().clear();
        }
        for (Pane c : columna) {
            c.getChildren().clear();
        }
        descarte.getChildren().clear();
        cartaPorNodo.clear();
    }

    private void pintarDesdeMotor() {
        List<List<CartaInglesa>> t = new ArrayList<>();
        for (TableauDeck td : juego.getTableau()) {
            t.add(td.getCards());
        }
        for (int i = 0; i < columna.size(); i++) {
            Pane cont = columna.get(i);
            cont.getChildren().clear();
            if (i < t.size()) {
                List<CartaInglesa> cartas = t.get(i);
                for (CartaInglesa ci : cartas) {
                    StackPane nodo = crearNodo(ci);
                    cont.getChildren().add(nodo);
                }
            }
            organizar(cont);
        }
        for (Pane f : fundacion) {
            f.getChildren().clear();
        }
        refrescarWaste();
    }

    private void refrescarWaste() {
        descarte.getChildren().clear();
        CartaInglesa w = juego.getWastePile().verCarta();
        if (w != null) {
            StackPane nodo = crearNodo(w);
            descarte.getChildren().add(nodo);
            organizar(descarte);
        }
    }


    private StackPane crearNodo(CartaInglesa ci) {
        StackPane n = new StackPane();
        n.setPrefSize(100, 140);
        String figura = ci.getPalo().getFigura();
        String figuraNormal = figura.replace("\uFE0E", "").replace("\uFE0F", "").replace("❤", "♥");
        String rango = convertir(ci.getValor());
        Carta c = new Carta(n, rango, figuraNormal, ci.getValor(), "rojo".equals(ci.getPalo().getColor()), ci.isFaceup());
        cartaPorNodo.put(n, c);
        c.actualizarRepresentacionVisual();
        arrastre.registrarCartaArrastrable(n);
        return n;
    }

    private String convertir(int v) {
        if (v == 14) {
            return "A";
        }
        if (v == 11) {
            return "J";
        }
        if (v == 12) {
            return "Q";
        }
        if (v == 13) {
            return "K";
        }
        return String.valueOf(v);
    }

    private void organizar(Pane pila) {
        boolean base = fundacion.contains(pila) || pila == descarte;
        double y = base ? 0 : margenSuperior;
        double paso = base ? 0 : pasoSolape;
        for (var n : pila.getChildren()) {
            n.setTranslateX(0);
            n.setTranslateY(y);
            y += paso;
        }
    }

    private boolean intentarConMotor(Pane origen, List<StackPane> grupo, Pane destino) {
        if (destino == null) {
            return false;
        }
        if (origen == descarte) {
            if (columna.contains(destino)) {
                int d = columna.indexOf(destino);
                boolean ok = juego.moveWasteToTableau(d + 1);
                if (ok) {
                    pintarCol(origen, destino);
                    refrescarWaste();
                    comprobar();
                }
                return ok;
            }
            if (fundacion.contains(destino)) {
                boolean ok = juego.moveWasteToFoundation();
                if (ok) {
                    actualizarFundacion();
                    refrescarWaste();
                    comprobar();
                }
                return ok;
            }
            return false;
        }
        if (columna.contains(origen)) {
            int o = columna.indexOf(origen);
            if (columna.contains(destino)) {
                int d = columna.indexOf(destino);
                boolean ok = juego.moveTableauToTableau(o + 1, d + 1);
                if (ok) {
                    pintarCol(origen, destino);
                    comprobar();
                }
                return ok;
            }
            if (fundacion.contains(destino)) {
                if (grupo.size() != 1) {
                    return false;
                }
                boolean ok = juego.moveTableauToFoundation(o + 1);
                if (ok) {
                    pintarSoloColumna(o);
                    actualizarFundacion();
                    comprobar();
                }
                return ok;
            }
            return false;
        }
        return false;
    }

    private void pintarCol(Pane origen, Pane destino) {
        if (columna.contains(origen)) {
            int i = columna.indexOf(origen);
            pintarSoloColumna(i);
        }
        if (columna.contains(destino)) {
            int j = columna.indexOf(destino);
            pintarSoloColumna(j);
        }
    }

    private void pintarSoloColumna(int i) {
        Pane cont = columna.get(i);
        cont.getChildren().clear();
        List<CartaInglesa> cartas = juego.getTableau().get(i).getCards();
        for (CartaInglesa ci : cartas) {
            StackPane nodo = crearNodo(ci);
            cont.getChildren().add(nodo);
        }
        organizar(cont);
    }

    private void actualizarFundacion() {
        FoundationDeck fd = juego.getLastFoundationUpdated();
        if (fd == null) {
            return;
        }
        CartaInglesa top = fd.getUltimaCarta();
        if (top == null) {
            return;
        }
        int idx = top.getPalo().ordinal();
        Pane base = fundacion.get(idx);
        base.getChildren().clear();
        StackPane nodo = crearNodo(top);
        base.getChildren().add(nodo);
        organizar(base);
    }

    private void manejarValido() {
        RecursosAudioMedia.reproducirEfecto("sonido_de_aprobacion");
    }

    private void manejarInvalido() {
        RecursosAudioMedia.reproducirEfecto("sonido_de_error");
    }

    private void comprobar() {
        if (victoriaMostrada) {
            return;
        }
        boolean ok = juego.isGameOver();
        if (ok) {
            victoriaMostrada = true;
            onVictoria.run();
        }
    }
}
